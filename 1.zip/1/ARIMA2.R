a <- read.csv(file = "prev_year_all.train.csv", header = TRUE)
Store <- read.csv(file = "stores.csv", header = TRUE)
#View(Store)
a$Store <- sub("^", "Store_", a$Store )
a$Dept <- sub("^", "Dept_", a$Dept )
Store$Store <- sub("^", "Store_", Store$Store )

Tab_data <- merge(a,Store, by= "Store", all = TRUE)

#a$MarkDown1 <- ifelse(a$MarkDown1 == NA,0, a$MarkDown1)

Tab_data[is.na(Tab_data)] <- 0
View(Tab_data)
#unique(a$Dept)

max_sales <- max(Tab_data$Weekly_Sales)
min_sales <- min(Tab_data$Weekly_Sales)

write.csv(Tab_data, file = "For_Tableau.csv")

Tab_data$cluster <- 0

cond <- Tab_data$Weekly_Sales < 0
Tab_data[cond, "cluster"] <- "1"

cond <- Tab_data$Weekly_Sales >= 0 & Tab_data$Weekly_Sales< 50000
Tab_data[cond, "cluster"] <- "2"

cond <- Tab_data$Weekly_Sales >= 50000 & Tab_data$Weekly_Sales< 100000
Tab_data[cond, "cluster"] <- "3"

cond <- Tab_data$Weekly_Sales >= 100000 & Tab_data$Weekly_Sales< 150000
Tab_data[cond, "cluster"] <- "4"

cond <- Tab_data$Weekly_Sales >= 150000 & Tab_data$Weekly_Sales< 200000
Tab_data[cond, "cluster"] <- "5"

cond <- Tab_data$Weekly_Sales >= 200000 & Tab_data$Weekly_Sales< 250000
Tab_data[cond, "cluster"] <- "6"

cond <- Tab_data$Weekly_Sales >= 250000 & Tab_data$Weekly_Sales< 300000
Tab_data[cond, "cluster"] <- "7"

cond <- Tab_data$Weekly_Sales >= 300000 & Tab_data$Weekly_Sales< 350000
Tab_data[cond, "cluster"] <- "8"

cond <- Tab_data$Weekly_Sales >= 350000 & Tab_data$Weekly_Sales< 400000
Tab_data[cond, "cluster"] <- "9"

cond <- Tab_data$Weekly_Sales >= 400000 & Tab_data$Weekly_Sales< 450000
Tab_data[cond, "cluster"] <- "10"

cond <- Tab_data$Weekly_Sales >= 450000 & Tab_data$Weekly_Sales< 500000
Tab_data[cond, "cluster"] <- "11"

cond <- Tab_data$Weekly_Sales >= 500000 & Tab_data$Weekly_Sales< 550000
Tab_data[cond, "cluster"] <- "12"

cond <- Tab_data$Weekly_Sales >= 550000 & Tab_data$Weekly_Sales< 600000
Tab_data[cond, "cluster"] <- "13"

cond <- Tab_data$Weekly_Sales >= 600000 & Tab_data$Weekly_Sales< 650000
Tab_data[cond, "cluster"] <- "14"

unique(Tab_data$cluster)

Tab_data$cluster <- sub("^", "Cluster_", Tab_data$cluster )

write.csv(Tab_data, file = "cluster_addition.csv")

############### Time Series Analysis ##################

install.packages("tseries")
library(tseries)
View(Tab_data)
y <- Tab_data$Weekly_Sales
y.diff <- diff(y)
t <- Tab_data$Date


################ Descriptive statistics and plotting the data ###########
summary(y)
summary(y.diff)

plot(t,y)
plot(y.diff)

######## Dickey fuller test for variables #####################
adf.test(y, alternative = "stationary", k=0)
adf.test(y, alternative = "explosive", k=0)

summary(lm(Tab_data$Weekly_Sales ~ Tab_data$prev_friday_sales + Tab_data$next_friday_sales,
           na.action = na.omit))

###### Augmented dickey fuller test ##############
adf.test(y, alternative = "stationary")

########### Dickey fuller test on differenced value #########
adf.test(y.diff, k=0)

########## Auto Corelation and partial auto correlation function #########

acf(y)
pacf(y)

acf(y.diff)
pacf(y.diff)


### AR(1) ######
arima(y, order = c(1,0,0))

### AR(2) ######
arima(y, order = c(2,0,0))

### MA(1) ######
arima(y, order = c(0,0,1))

### AR(1) MA(1) ######
arima(y, order = c(1,0,1))

### Plots or ARIMA model ######

testarima <- arima(y, order = c(1,0,1))
testpred <- predict(testarima,n.ahead=100)
plot(y)
lines(testpred$pred , col="blue")
lines(testpred$pred+2 * testpred$se, col="red")
lines(testpred$pred-2 * testpred$se, col="red")


testarima <- arima(y.diff, order = c(1,0,1))
testpred <- predict(testarima,n.ahead=100)
plot(y.diff)
lines(testpred$pred , col="blue")
lines(testpred$pred+2 * testpred$se, col="red")
lines(testpred$pred-2 * testpred$se, col="red")


###########################################################
date_df <- as.data.frame(Tab_data$Date)
sales_df <- as.data.frame(Tab_data$Weekly_Sales)
for_arima <- cbind.data.frame(date_df,sales_df)

write.csv2(date_df, file = "date_df.csv")
write.csv2(sales_df, file = "sales_df.csv")
write.csv(for_arima, file = "for_arima.csv", sep = ";")

######################################
date_arima <- as.Date(Tab_data$Date, format = "%m/%d/%Y")
sales_arima <- Tab_data$Weekly_Sales

arima_data <- cbind(date_arima, sales_arima)
View(arima_data)

str(Tab_data)
Tab_data$Date <- as.Date(Tab_data$Date)
