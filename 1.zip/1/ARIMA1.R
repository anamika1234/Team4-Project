a <- read.csv(file = "prev_year_all.train.csv", header = TRUE)
Store <- read.csv(file = "stores.csv", header = TRUE)
View(Store)
a$Store <- sub("^", "Store_", a$Store )
a$Dept <- sub("^", "Dept_", a$Dept )
Store$Store <- sub("^", "Store_", Store$Store )

Tab_data <- merge(a,Store, by= "Store", all = TRUE)

#a$MarkDown1 <- ifelse(a$MarkDown1 == NA,0, a$MarkDown1)

Tab_data[is.na(Tab_data)] <- 0
View(Tab_data)
#unique(a$Dept)

write.csv(Tab_data, file = "For_Tableau.csv")

############### Time Series Analysis ##################

install.packages("tseries")
library(tseries)
View(Tab_data)
y <- Tab_data$Weekly_Sales
y.diff <- diff(y)
t <- Tab_data$Date


################ Descriptive statistics and plotting the data ###########
summary(y)
summary(y.diff)

plot(t,y)
plot(y.diff)

######## Dickey fuller test for variables #####################
adf.test(y, alternative = "stationary", k=0)
adf.test(y, alternative = "explosive", k=0)

summary(lm(Tab_data$Weekly_Sales ~ Tab_data$prev_friday_sales + Tab_data$next_friday_sales,
           na.action = na.omit))

###### Augmented dickey fuller test ##############
adf.test(y, alternative = "stationary")

########### Dickey fuller test on differenced value #########
adf.test(y.diff, k=0)

########## Auto Corelation and partial auto correlation function #########

acf(y)
pacf(y)

acf(y.diff)
pacf(y.diff)


### AR(1) ######
arima(y, order = c(1,0,0))

### AR(2) ######
arima(y, order = c(2,0,0))

### MA(1) ######
arima(y, order = c(0,0,1))

### AR(1) MA(1) ######
arima(y, order = c(1,0,1))

arima(y.diff, order = c(1,0,0))
testarima <- arima(y.diff, order = c(1,0,1))
testpred <- predict(testarima,n.head=100)
 plot(y)
lines(testpred$pred , col="blue")
lines(testpred$pred+2 * testpred$se, col="red")
lines(testpred$pred-2 * testpred$se, col="red")

arima(x=y.diff, order=c(2,0,3))



